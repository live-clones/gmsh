
2D and 3D model of an inductor/core system.

[[Category:GetDP]]
[[Category:Electromagnetism]]

<!--

Open inductor.pro

Link to FEMM model

-->
